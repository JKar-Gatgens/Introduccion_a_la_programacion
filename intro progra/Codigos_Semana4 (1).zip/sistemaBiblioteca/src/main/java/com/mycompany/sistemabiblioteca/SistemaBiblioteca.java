/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemabiblioteca;

import java.util.Date;
import objetosBiblioteca.Biblioteca;
import objetosBiblioteca.Libro;
import objetosBiblioteca.Prestamo;
import objetosBiblioteca.Usuario;

/**
 *
 * @author josea
 */
public class SistemaBiblioteca {

    public static void main(String[] args) {
        
        // Creacion biblioteca
        Biblioteca instanciaBiblioteca = new Biblioteca();
        
        // Vamos a crear algunos libros
        Libro libro1 = new Libro("El Quijote", "Miguel de Cervantes", "1234567890", 1605);
        Libro libro2 = new Libro("1984", "George Orwell", "0987654321", 1949);
        Libro libro3 = new Libro("Cien anios de soledad", "Gabriel Garcia Marquez", "11223344555", 1967);
        
        // Agregar libros al catalogo de la biblioteca
        instanciaBiblioteca.agregarLibro(libro1);
        instanciaBiblioteca.agregarLibro(libro2);
        instanciaBiblioteca.agregarLibro(libro3);
        
        // Crear algunos usuarios
        Usuario usuario1 = new Usuario("Juan", "Perez", "U001");
        Usuario usuario2 = new Usuario("Maria", "Gonzalez", "U002");
        
        // Registrar usuarios en la biblioteca
        instanciaBiblioteca.registrarUsuario(usuario1);
        instanciaBiblioteca.registrarUsuario(usuario2);
        
        
        // Listar libros disponibles antes de realizar prestamos
        System.out.println("Libros disponibles antes de los prestamos: ");
        instanciaBiblioteca.listarLibrosDisponibles();
        System.out.println();
        
        
        //Realizar algunos prestamos
        usuario1.realizarPrestamo(libro1);
        usuario2.realizarPrestamo(libro2);
        
        // Listar libros disponibles despues de realizar prestamos
        System.out.println("Libros disponibles despues de los prestamos");
        instanciaBiblioteca.listarLibrosDisponibles();
        System.out.println();
        
        // Devolver un libro
        usuario1.devolverLibro(libro1);
        
        // Listar libros disponibles despues de la devolucion
        System.out.println("Libros disponibles despues de la devolucion");
        instanciaBiblioteca.listarLibrosDisponibles();
        System.out.println();
        
        for (Prestamo prestamo : usuario1.getPrestamos()) {
            Date fechaTardia = new Date(prestamo.getFechaPrestamo().getTime() + (16 * 24 * 60 * 60 * 1000));
            prestamo.setFechaDevolucion(fechaTardia);
            double multa = prestamo.calcularMulta();
            System.out.println("Multa por la devolucion tardia del libro \n" + libro1.getTitulo() + " " + multa);
            break;
        }
        
        
    }
}
