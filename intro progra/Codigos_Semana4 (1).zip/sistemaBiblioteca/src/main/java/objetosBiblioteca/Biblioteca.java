/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetosBiblioteca;

import java.util.ArrayList;

/**
 *
 * @author josea
 */
public class Biblioteca {
    public ArrayList<Libro> catalogo;
    public ArrayList<Usuario> usuarios;
    
    public Biblioteca() {
        this.catalogo = new ArrayList<>();
        this.usuarios = new ArrayList<>();
    }
    
    public void agregarLibro(Libro libro) {
        this.catalogo.add(libro);
    }
    
    public void registrarUsuario(Usuario usuario) {
        this.usuarios.add(usuario);
    }
    
    public void listarLibrosDisponibles() {
        for(Libro libro: catalogo) {
            if (libro.isDisponible()) {
                System.out.println(libro.getTitulo());
            }
        }
    }
}
