/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetosBiblioteca;

/**
 *
 * @author josea
 */
public class Libro {
    public String titulo;
    public String autor;
    public String ISBN;
    public int anioPublicacion;
    public boolean disponible;
    
    public Libro(String titulo, String autor, String ISBN, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.ISBN = ISBN;
        this.anioPublicacion = anioPublicacion;
        this.disponible = true;
    }
    
    
    public String getTitulo() {
        return this.titulo;
    }
    
    public boolean isDisponible() {
        return this.disponible;
    }
    
    public void prestamo() {
        if (this.disponible) {
            this.disponible = false;
        }
    }
    
    public void devolucion() {
        this.disponible = true;
    }
    
}
