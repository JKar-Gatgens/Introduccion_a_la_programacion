/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetosBiblioteca;

import java.util.Date;

/**
 *
 * @author josea
 */
public class Prestamo {
    public Usuario usuario;
    public Libro libro;
    public Date fechaPrestamo;
    public Date fechaDevolucion;
    
    public Prestamo(Usuario usuario, Libro libro) {
        this.usuario = usuario;
        this.libro = libro;
        this.fechaPrestamo = new Date();
        this.fechaDevolucion = null;
    }
    
    public Date getFechaPrestamo() {
        return this.fechaPrestamo;
    }
    
    public void setFechaDevolucion(Date fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }
    
    public Libro getLibro() {
        return this.libro;
    }
    
    
    public double calcularMulta() {
        if (fechaDevolucion != null) {
            long diferencia = fechaDevolucion.getTime() - fechaPrestamo.getTime();
            long dias = diferencia / (1000 * 60 * 60 * 24);
            if (dias > 14) {
                return (dias - 14) * 1.0;
            }
        }
        return 0.0;
    }
    
    
}
