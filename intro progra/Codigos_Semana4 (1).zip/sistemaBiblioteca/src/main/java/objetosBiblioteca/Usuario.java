/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetosBiblioteca;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author josea
 */
public class Usuario {
    public String nombre;
    public String apellido;
    public String id;
    public ArrayList<Prestamo> prestamos;
    
    public Usuario(String nombre, String apellido, String id) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.id = id;
        this.prestamos = new ArrayList<>();
    }
    
    public ArrayList<Prestamo> getPrestamos() {
        return this.prestamos;
    }
    
    public void realizarPrestamo(Libro libro) {
        if (libro.isDisponible()) {
            Prestamo prestamo = new Prestamo(this, libro);
            prestamos.add(prestamo);
            libro.prestamo();
        }
    }
    
    public void devolverLibro(Libro libro) {
        for (Prestamo prestamo : prestamos) {
            if (prestamo.getLibro().equals(libro)) {
                prestamo.setFechaDevolucion(new Date());
                libro.devolucion();
                break;
            }
        }
    }
    
    
}
