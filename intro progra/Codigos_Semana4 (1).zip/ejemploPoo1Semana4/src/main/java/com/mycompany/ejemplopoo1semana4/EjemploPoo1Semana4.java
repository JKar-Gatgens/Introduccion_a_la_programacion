/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplopoo1semana4;

import javax.swing.JOptionPane;
import objetos_ejemplo.Persona;
import objetos_ejemplo.Vehiculo;

/**
 *
 * @author josea
 */
public class EjemploPoo1Semana4 {

    public static void main(String[] args) {
        Persona instanciaDePersona1 = new Persona("Juan", "Alcazar", "1721", 22);
        Persona instanciaDePersona2 = new Persona("Pedro", "Alvar", "5543", 50);
        
//        Vehiculo instanciaDeVehiculo1 = new Vehiculo("BGG-107", "Toyota", "Diesel", 2005);
//        instanciaDeVehiculo1.tipoCombustible = "GAS-GLP";

        Vehiculo instanciaDeVehiculo1 = new Vehiculo();
        instanciaDeVehiculo1.tipoCombustible = JOptionPane.showInputDialog("Introducir tipo de combustible: ");
        
        System.out.println(instanciaDePersona1.getNombre());
        System.out.println(instanciaDePersona2.getNombre());
        
        System.out.println(instanciaDeVehiculo1.tipoCombustible);
    }
}
