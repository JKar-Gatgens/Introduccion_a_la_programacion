/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos_ejemplo;

/**
 *
 * @author josea
 */
public class Vehiculo {
    public String placa;
    public String fabricante;
    public String tipoCombustible;
    public int annio;
    
    public Vehiculo() {
    }
    
    public Vehiculo(String placa, String fabricante, String tipoCombustible, int annio) {
        this.placa = placa;
        this.fabricante = fabricante;
        this.tipoCombustible = tipoCombustible;
        this.annio = annio;
    }
    
    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    public String getPlaca() {
        return this.placa;
    }
    
}
