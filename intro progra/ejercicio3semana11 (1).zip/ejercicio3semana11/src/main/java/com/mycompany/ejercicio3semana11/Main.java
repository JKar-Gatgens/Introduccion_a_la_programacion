/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio3semana11;

import modulos.Empleado;

/**
 *
 * @author josea
 */
public class Main {
    
    public static void main(String[] args) {
        Empleado[] empleados = new Empleado[3];
        
        empleados[0] = new Empleado("Carlos", "Gerente", 5000.0);
        empleados[1] = new Empleado("Laura", "Asistente", 2500.0);
        empleados[2] = new Empleado("Pedro", "Desarrollador", 3500);
        
        mostrarEmpleados(empleados);
        buscarPorPuesto(empleados, "Desarrollador");
        Empleado mejorPagado = encontrarMejorPagado(empleados);
        System.out.println("Empleado mejor pagado: " + mejorPagado.nombre + ", Salario: " + mejorPagado.salario);
    }
    
    public static void mostrarEmpleados(Empleado[] empleados) {
        for (Empleado e : empleados) {
            System.out.println("Nombre: " + e.nombre + ", Puesto: " + e.puesto + ", Salario: " + e.salario );
        }
    }
    
    public static void buscarPorPuesto(Empleado[] empleados, String puesto) {
        for (Empleado e : empleados) {
            if (e.puesto.equals(puesto)) {
                System.out.println("Empleado encontrado: " + e.nombre + ", Puesto: " + e.puesto);
                return;
            }
        }
        System.out.println("Puesto no encontrado");
    }
    
    public static Empleado encontrarMejorPagado(Empleado[] empleados) {
        Empleado mejorPagado = empleados[0];
        
        for (Empleado e : empleados) {
            if(e.salario > mejorPagado.salario) {
                mejorPagado = e;
            }
        }
        return mejorPagado;
    }
    
}
