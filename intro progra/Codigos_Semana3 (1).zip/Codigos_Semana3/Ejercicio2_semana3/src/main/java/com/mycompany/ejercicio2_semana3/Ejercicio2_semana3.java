/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2_semana3;

/**
 *
 * @author josea
 */
public class Ejercicio2_semana3 {

    public static void main(String[] args) {
        //ejercicio 2 semana 3
    int i=1, suma=0;
    
    while (i <= 10) {
        suma += i;
        System.out.println(i);
        i++;
    }
    System.out.println("la sumatoria es: "+suma);
    }
}
