/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio3_semana3;

/**
 *
 * @author josea
 */
public class Ejercicio3_semana3 {

    public static void main(String[] args) {
        //ejercicio 3 semana 
        for (int j = 0; j < 5; j++)  { 
            for (int i = 0; i < 10; i++)  {
                System.out.print("@");
            }
            System.out.println();
        }
    }
}
