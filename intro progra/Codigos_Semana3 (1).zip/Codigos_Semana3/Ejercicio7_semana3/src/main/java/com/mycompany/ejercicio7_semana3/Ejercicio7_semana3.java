/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio7_semana3;

import javax.swing.JOptionPane;

/**
 *
 * @author josea
 */
public class Ejercicio7_semana3 {

    public static void main(String[] args) {
        //ejercicio 7 semana 3
int numero = Integer.parseInt(JOptionPane.showInputDialog("ingrese numero: "));

for(int i=1; i<=numero; i++) {
    
    int temp = i;
    
    while(temp > 0) {
       System.out.print("*");
       temp--;
    }
    System.out.println();
}
    }
}
