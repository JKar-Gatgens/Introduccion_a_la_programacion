/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio9_semana3;

import javax.swing.JOptionPane;

/**
 *
 * @author josea
 */
public class Ejercicio9_semana3 {

    public static void main(String[] args) {
        //ejercicio 9 semana 3
//int numeroEstudiantes = Integer.parseInt(JOptionPane.showInputDialog("ingrese cant estudiantes: "));
double notaMayor = 0;
double notaMenor = 100;
double sumatoria = 0;
double promedio = 0;
int cantEstudiantesProcesados=0;
int cantAprobados = 0;
boolean continuar = true;
int i = 1;

while (continuar) {
    double notaEstudiante = Double.parseDouble(JOptionPane.showInputDialog("ingrese nota estudiante "+ i + ":"));
    
    if (notaEstudiante < 0) {
        continuar = false;
    } else {
        
    if (notaMayor < notaEstudiante) {
        notaMayor = notaEstudiante;
    }
    
    if (notaMenor > notaEstudiante) {
        notaMenor = notaEstudiante;
    }
    
    sumatoria += notaEstudiante;
    
    if (notaEstudiante >= 70) {
    cantAprobados++;
    }
    i++;
    cantEstudiantesProcesados++;
    }
    
}

promedio = sumatoria / cantEstudiantesProcesados;


JOptionPane.showMessageDialog(null, "nota Mayor: "+ notaMayor + "\n" +
        " nota Menor: "+ notaMenor+ "\n" +
        " promedio: "+ promedio + "\n" +
        "cant aprobados: "+ cantAprobados);
    }
}
