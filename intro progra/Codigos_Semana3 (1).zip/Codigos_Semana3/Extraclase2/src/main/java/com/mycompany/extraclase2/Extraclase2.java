/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.extraclase2;

import javax.swing.JOptionPane;

/**
 *
 * @author josea
 */
public class Extraclase2 {

    public static void main(String[] args) {
   int annosAntiguedad = Integer.parseInt(JOptionPane.showInputDialog("Introducir annos de antiguedad: "));
   double horasPorSemana = Double.parseDouble(JOptionPane.showInputDialog("Cantidad de horas laboradas por semana:"));
   double precioHora = Double.parseDouble(JOptionPane.showInputDialog("Precio que se paga por horas: "));
   
   double horasPorMes = horasPorSemana * 4;
   double salarioBruto = horasPorMes * precioHora;
   double bono = 0;
   double deduccion = 0;
   double salarioNeto;
   
   if (annosAntiguedad > 10) {
       bono = salarioBruto * 0.2;
   }
   
   if ((salarioBruto + bono) > 1000) {
       deduccion = (salarioBruto + bono) * 0.1;
   } else if ((salarioBruto + bono) > 1000) {
       deduccion = (salarioBruto + bono) * 0.15;
   }
   
   salarioNeto = salarioBruto + bono - deduccion;
   
   JOptionPane.showMessageDialog(null, 
           "Su salario bruto es: " + salarioBruto + "\n" +
           "Su bono es: " + bono + "\n" +
           "Su deduccion es: " + deduccion + "\n" +
           "Su salario neto es: " + salarioNeto);
   

   
//   JOptionPane.showMessageDialog(null, "Estimado " + nombreTrabajador + 
//           ", el salario de este mes se desglosa de la siguiente manera \n" + 
//                   "Salario bruto: " + salarioBruto + "\n" + 
//                   "Deducciones: " + deducciones + "\n" + 
//                           "Salario Neto: " + salarioNeto);
    }
}
