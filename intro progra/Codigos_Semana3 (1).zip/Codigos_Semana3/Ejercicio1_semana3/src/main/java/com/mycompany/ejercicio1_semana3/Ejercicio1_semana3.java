/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1_semana3;

/**
 *
 * @author josea
 */
public class Ejercicio1_semana3 {

    public static void main(String[] args) {
    //ejercicio 1 semana 3
        for (int i = 0; i < 5; i++) {
            System.out.println("El valor de i: " + i);
        }
        for (int i = 10; i > 0; i--) {
            System.out.println(i);
        }
        System.out.println("Feliz anno nuevo");
    }
}
