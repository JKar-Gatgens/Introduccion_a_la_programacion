/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio5_semana3;

/**
 *
 * @author josea
 */
public class Ejercicio5_semana3 {

    public static void main(String[] args) {
        //ejercicio 5 semana 3
int i = 0;

while (i < 7) {
    
    int j = 0;
    System.out.println("Ejecutando ciclo externo i="+i);
    
    while (j < 4) {
    System.out.println();
    System.out.printf("Ejecutando ciclo interno i="+i+"j="+j);
    j++;
    }
    i++;
}
System.out.println();
    }
}
