/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio8_semana3;

/**
 *
 * @author josea
 */
public class Ejercicio8_semana3 {

    public static void main(String[] args) {
        //ejercicio 8 semana 3
for (int i = 20; i <= 30; i++) {
    System.out.println("valor :" + i);
    System.out.println("valor cuadrado: "+ i*i);
}
    }
}
