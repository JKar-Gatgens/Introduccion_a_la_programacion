/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio4_semana4;

/**
 *
 * @author josea
 */
public class Ejercicio4_semana4 {

    public static void main(String[] args) {
        
        //ejercicio 4 semana 3
        int i=0;
        do {
            System.out.println("Hola, i vale: " + i);
            ++i;
        } while (i<5);
    }
}
