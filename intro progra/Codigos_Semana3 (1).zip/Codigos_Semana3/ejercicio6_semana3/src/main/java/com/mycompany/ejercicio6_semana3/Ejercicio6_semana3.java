/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio6_semana3;

import javax.swing.JOptionPane;

/**
 *
 * @author josea
 */
public class Ejercicio6_semana3 {

    public static void main(String[] args) {
        //ejercicio 6 semana 3
    int numero;
    
    numero = Integer.parseInt(JOptionPane.showInputDialog("ingresar numero"));
    
    for(int i = 1; i <= 10; i++) {
    int resultado = numero * i;
    System.out.println(numero + " x " + i + " = " +resultado);
    }
    }
}
