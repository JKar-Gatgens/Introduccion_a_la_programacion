/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.extraclase1;
import javax.swing.JOptionPane;
/**
 *
 * @author josea
 */
public class main {
    
    public static void main(String[] args) {
        
   String nombreTrabajador = JOptionPane.showInputDialog("Introducir nombre: ");
   double salarioSemanal = Double.parseDouble(JOptionPane.showInputDialog("Introducir salario semanal: "));
   double salarioBruto = salarioSemanal * 4;
   double deducciones = salarioBruto * 0.0934;
   double salarioNeto = salarioBruto - deducciones;
   
   JOptionPane.showMessageDialog(null, "Estimado " + nombreTrabajador + 
           ", el salario de este mes se desglosa de la siguiente manera" + "\n" +
                   "Salario bruto: " + salarioBruto + "\n" + 
                   "Deducciones: " + deducciones + "\n" + 
                           "Salario Neto: " + salarioNeto);
    }

}
