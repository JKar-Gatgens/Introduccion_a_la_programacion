/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio0_semana1;
import javax.swing.JOptionPane;
/**
 *
 * @author josea
 * Ejercicio0_semana1
 Escriba un programa que muestre lo siguiente:
 Bienvenido al mundo de Java.
 Podrás dar solución a muchos problemas.
 Impleméntelo utilizando dos instrucciones de impresión e intento 
 hacerlo con una sola instrucción. 
 Pruebe las diferentes posibilidades que se le han presentado
 */
public class main {

    public static void main(String[] args) {
        String linea1 = "Bienvenido al mundo de Java \n Podras dar solucion a muchos problemas";
        JOptionPane.showMessageDialog(null, linea1);
    }
}
