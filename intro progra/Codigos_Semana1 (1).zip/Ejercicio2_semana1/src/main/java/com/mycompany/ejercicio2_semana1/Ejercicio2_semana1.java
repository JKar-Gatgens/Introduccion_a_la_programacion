/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2_semana1;
import javax.swing.JOptionPane;
/**
 *
 * @author josea
 */
public class Ejercicio2_semana1 {

    public static void main(String[] args) {
        String nombre = JOptionPane.showInputDialog("Digite su nombre: ");
        JOptionPane.showMessageDialog(null, "Hola " + nombre + ",  bienvenida a este programa desarrollado en JAVA con Netbeans.");
    }
}
