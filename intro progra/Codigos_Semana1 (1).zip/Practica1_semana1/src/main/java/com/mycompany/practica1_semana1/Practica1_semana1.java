/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practica1_semana1;
import javax.swing.JOptionPane;
/**
 *
 * @author josea
 */
public class Practica1_semana1 {

    public static void main(String[] args) {
        int edad;
        edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese edad: "));
        JOptionPane.showMessageDialog(null, "Dentro de 5 annos, tendra: "+(edad + 5));
    }
}
