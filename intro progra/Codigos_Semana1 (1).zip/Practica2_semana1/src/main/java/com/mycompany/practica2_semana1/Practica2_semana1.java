/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practica2_semana1;
import javax.swing.JOptionPane;
/**
 *
 * @author josea
 */
public class Practica2_semana1 {

    public static void main(String[] args) {
        double ingreso;
        double gasto;
        
        ingreso = Double.parseDouble(JOptionPane.showInputDialog("ingresar ingreso: "));
        gasto = Double.parseDouble(JOptionPane.showInputDialog("ingrese gasto: "));
        
        double porcentaje = (gasto / ingreso) * 100;
        
        JOptionPane.showMessageDialog(null, "El porcentaje de gastos representa " + porcentaje + "%");
    }
}
