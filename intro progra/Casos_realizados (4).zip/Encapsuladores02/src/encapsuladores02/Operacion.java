package encapsuladores02;
public class Operacion {
   private float primerNumero;
   private float segundoNumero;
   private float resultado;
   
   public Operacion(){
      this.primerNumero=0.00f;
      this.segundoNumero=0.00f;
      this.resultado=0.00f;
   }

    public Operacion(float primerNumero, float segundoNumero) {
        this.primerNumero = primerNumero;
        this.segundoNumero = segundoNumero;
    }
   
   public float getPrimerNumero() {
        return primerNumero;
    }

    public void setPrimerNumero(float primerNumero) {
        this.primerNumero = primerNumero;
    }

    public float getSegundoNumero() {
        return segundoNumero;
    }

    public void setSegundoNumero(float segundoNumero) {
        this.segundoNumero = segundoNumero;
    }
    
    public float calcularSuma(){
       resultado=primerNumero+segundoNumero;
       return resultado;
    }
    
    public float calcularResta(){
       resultado=primerNumero-segundoNumero;
       return resultado;
    }
    
    public float calcularMultiplicacion(){
       resultado=primerNumero*segundoNumero;
       return resultado;
    }
    
    public float calcularDivision(){
       resultado=primerNumero/segundoNumero;
       return resultado;
    }
}
