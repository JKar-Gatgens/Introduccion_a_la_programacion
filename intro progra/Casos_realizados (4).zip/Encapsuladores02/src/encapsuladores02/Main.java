package encapsuladores02;
import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args) {
       Operacion op01=new Operacion();
       Operacion op02=new Operacion();
       op01.setPrimerNumero(Float.parseFloat(JOptionPane.showInputDialog(null,
               "Digite el primer número:")));
       op01.setSegundoNumero(Float.parseFloat(JOptionPane.showInputDialog(null,
               "Digite el segundo número:")));
       op02.setPrimerNumero(Float.parseFloat(JOptionPane.showInputDialog(null,
               "Digite el primer número:")));
       op02.setSegundoNumero(Float.parseFloat(JOptionPane.showInputDialog(null,
               "Digite el segundo número:")));
       Operacion op03=new Operacion(10.5f,2.2f);
       JOptionPane.showMessageDialog(null,
               "OPERACIONES CON LA PRIMERA SERIE:\n\nPrimer número:"+op01.getPrimerNumero()+
                       "\nSegundo número:"+op01.getSegundoNumero()+"\nSuma:"+op01.calcularSuma()+
                       "\nResta:"+op01.calcularResta()+"\nMultiplicación:"+op01.calcularMultiplicacion()+
                       "\nDivisión:"+op01.calcularDivision()+
                       "\n\nOPERACIONES CON LA SEGUNDA SERIE:\n\nPrimer número:"+op02.getPrimerNumero()+
                       "\nSegundo número:"+op02.getSegundoNumero()+"\nSuma:"+op02.calcularSuma()+
                       "\nResta:"+op02.calcularResta()+"\nMultiplicación:"+op02.calcularMultiplicacion()+
                       "\nDivisión:"+op02.calcularDivision());

       JOptionPane.showMessageDialog(null,"OPERACIONES CON LA TERCERA SERIE:\n\n\nSuma:"+op03.calcularSuma()+
                       "\nResta:"+op03.calcularResta()+"\nMultiplicación:"+op03.calcularMultiplicacion()+
                       "\nDivisión:"+op03.calcularDivision());
    }    
}
