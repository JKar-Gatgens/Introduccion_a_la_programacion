package claseestatica;
public enum Calificacion {
   Excelente, Buena, Regular;    
}
