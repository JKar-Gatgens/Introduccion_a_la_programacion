package claseestatica;
import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args) {
       Universidad.setNombreUniversidad(JOptionPane.showInputDialog(null,
               "Digite el nombre de la universidad:"));
       Universidad.setDireccion(JOptionPane.showInputDialog(null,
               "Digite la dirección de la universidad"));
       Universidad.setTiempoFundacion(Float.parseFloat(JOptionPane.showInputDialog(null,
               "Digite el tiempo de fundación de la Universidad:")));
       JOptionPane.showMessageDialog(null,"La universidad "+Universidad.getNombreUniversidad()+
               " está ubicada es "+Universidad.getDireccion()+" y se creó hace "+
               Universidad.getTiempoFundacion()+" años. La calificación es "+Calificacion.Buena);
    }    
}
