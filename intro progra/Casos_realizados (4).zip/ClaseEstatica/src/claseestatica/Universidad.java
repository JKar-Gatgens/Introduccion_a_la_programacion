package claseestatica;

public class Universidad {

    private static String nombreUniversidad;
    private static String direccion;
    private static float tiempoFundacion;
    public Calificacion calidad;

    public Universidad() {
        Universidad.nombreUniversidad = "";
        Universidad.direccion = "";
        Universidad.tiempoFundacion = 0.00f;
    }

    public static String getNombreUniversidad() {
        return nombreUniversidad;
    }

    public static void setNombreUniversidad(String aNombreUniversidad) {
        nombreUniversidad = aNombreUniversidad;
    }

    public static String getDireccion() {
        return direccion;
    }

    public static void setDireccion(String aDireccion) {
        direccion = aDireccion;
    }

    public static float getTiempoFundacion() {
        return tiempoFundacion;
    }

    public static void setTiempoFundacion(float aTiempoFundacion) {
        tiempoFundacion = aTiempoFundacion;
    }

}
