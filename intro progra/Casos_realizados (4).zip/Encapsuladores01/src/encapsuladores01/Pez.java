package encapsuladores01;

public class Pez {

    private String nombre;
    private String especie;
    private float tiempoVida;
    private double precio;

    public Pez() {
        this.nombre = "";
        this.especie = "";
        this.tiempoVida = 0.00f;
        this.precio = 0.00;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public float getTiempoVida() {
        return tiempoVida;
    }

    public void setTiempoVida(float tiempoVida) {
        this.tiempoVida = tiempoVida;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

}
