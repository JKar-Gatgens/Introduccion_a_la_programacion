package encapsuladores01;
import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args) {
       Pez pez01=new Pez();
       Pez pez02=new Pez();
       pez01.setNombre(JOptionPane.showInputDialog(null,
               "Digite el nombre del pez:"));
       pez01.setEspecie(JOptionPane.showInputDialog(null,
               "Digite la especie:"));
       pez01.setPrecio(Double.parseDouble(JOptionPane.showInputDialog(null,
               "Digite el precio:")));
       pez01.setTiempoVida(Float.parseFloat(JOptionPane.showInputDialog(null,
               "Digite el tiempo de vida:")));
       pez02.setNombre(JOptionPane.showInputDialog(null,
               "Digite el nombre del pez:"));
       pez02.setEspecie(JOptionPane.showInputDialog(null,
               "Digite la especie:"));
       pez02.setPrecio(Double.parseDouble(JOptionPane.showInputDialog(null,
               "Digite el precio:")));
       pez02.setTiempoVida(Float.parseFloat(JOptionPane.showInputDialog(null,
               "Digite el tiempo de vida:")));
       JOptionPane.showMessageDialog(null,pez01.getNombre()+" pertenece a la especie "+
               pez01.getEspecie()+" tiene un precio de ¢ "+pez01.getPrecio()+
                       " y su estimación de vida es "+pez01.getTiempoVida()+" años."+
               pez02.getNombre()+" pertenece a la especie "+pez02.getEspecie()+
               " tiene un precio de ¢ "+pez02.getPrecio()+
               " y su estimación de vida es "+pez02.getTiempoVida()+" años.");
    }    
}
