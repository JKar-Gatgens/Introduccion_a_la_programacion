/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio1semana10;

import modulos.Estudiante;

/**
 *
 * @author josea
 */
public class Main {
    
    public static void main(String[] args) {
        Estudiante[] estudiantes = new Estudiante[3];
        
        estudiantes[0] = new Estudiante("Juan", 20, 8.5);
        estudiantes[1] = new Estudiante("Ana", 22, 9.0);
        estudiantes[2] = new Estudiante("Luis", 19, 7.8);
        
        mostrarEstudiantes(estudiantes);
        System.out.println("Promedio de notas: " + calcularPromedio(estudiantes));
        Estudiante mejorEstudiante = encontrarMejorEstudiante(estudiantes);
        System.out.println("Mejor estudiante: " + mejorEstudiante.nombre + " con nota " + mejorEstudiante.notaPromedio);
        
    }
    
    public static void mostrarEstudiantes(Estudiante[] estudiantes) {    
        for (Estudiante e : estudiantes) {
            System.out.println("Nombre: " + e.nombre + ", Edad: " + e.edad + ", Nota Promedio: " + e.notaPromedio);
        }
    }
    
    public static double calcularPromedio(Estudiante[] estudiantes) {
        double suma = 0;
        for (Estudiante est : estudiantes) {
            suma += est.notaPromedio;
        }
        return suma / estudiantes.length;
    }
    
    public static Estudiante encontrarMejorEstudiante(Estudiante[] estudiantes) {
        Estudiante mejor = estudiantes[0];
        for (Estudiante e : estudiantes) {
            if (e.notaPromedio > mejor.notaPromedio) {
                mejor = e;
            }
        }
        return mejor;
    }
    
}
