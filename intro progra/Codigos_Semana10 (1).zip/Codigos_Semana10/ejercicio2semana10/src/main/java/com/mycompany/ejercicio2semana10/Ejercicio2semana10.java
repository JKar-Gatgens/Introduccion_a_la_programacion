/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2semana10;

import modulos.Producto;

/**
 *
 * @author josea
 */
public class Ejercicio2semana10 {

    public static void main(String[] args) {
        Producto[] productos = new Producto[3];
        
        productos[0] = new Producto("Laptop", 1500.0, 5);
        productos[1] = new Producto("Mouse", 25.0, 20);
        productos[2] = new Producto("Teclado", 45.0, 10);
        
        mostrarProductos(productos);
        buscarProducto(productos, "Mouse");
        actualizarInventario(productos, "Teclado", 15);
        System.out.println("Valor total del inventario: " + calcularValorInventario(productos));
        
    }
    
    
    public static void mostrarProductos(Producto[] productos) {
        for (Producto p: productos) {
            System.out.println("Nombre: " + p.nombre + ", Precio: " + p.precio + ", Cantidad: " + p.cantidadEnInventario);
        }
    }
    
    public static void buscarProducto(Producto[] productos, String nombre) {
    
        for (Producto p : productos) {
            if (p.nombre.equals(nombre)) {
                System.out.println(" Producto encontrado: " + p.nombre + ", Precio: " + p.precio + ", Cantidad: " + p.cantidadEnInventario); 
                return;
            }
        }
        
        System.out.println("Producto no encontrado");
    }
    
    public static void actualizarInventario(Producto[] productos, String nombre, int nuevaCantidad) {
        for (Producto p: productos) {
            
            if (p.nombre.equals(nombre)) {
                p.cantidadEnInventario = nuevaCantidad;
                System.out.println("Cantidad actualizada para " + p.nombre + ": " + p.cantidadEnInventario);
                return;
            }
        }
        
        System.out.println("Producto no encontrado");
    }
    
    public static double calcularValorInventario(Producto[] productos) {
        double valorTotal = 0;
        for (Producto p: productos) {
            valorTotal += p.precio * p.cantidadEnInventario;
        }
        
        return valorTotal;
    }
    
    
}
