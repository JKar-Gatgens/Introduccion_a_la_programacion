/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1_semana2;
import javax.swing.JOptionPane;
/**
 *
 * @author josea
 */
public class Ejercicio1_semana2 {

    public static void main(String[] args) {
        int numero;
        numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese numero de la semana"));
        
        if (numero == 1) {
            System.out.println("Domingo");
        } else if (numero == 2) {
            System.out.println("Lunes");
        } else if (numero == 3) {
            System.out.println("Martes");
        } else if (numero == 4) {
            System.out.println("Miercoles");
        } else if (numero == 5) {
            System.out.println("Jueves");
        } else if (numero == 6) {
            System.out.println("Viernes");
        } else if (numero == 7) {
            System.out.println("Sabado");
        }
    }
}
