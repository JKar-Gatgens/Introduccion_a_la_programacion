/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio3_semana2;
import javax.swing.JOptionPane;
/**
 *
 * @author josea
 */
public class Ejercicio3_semana2 {

    public static void main(String[] args) {
        int numero1;
        int numero2;
        int numero3;
        int numero4;
        int numeroMayor;
        
        numero1 = Integer.parseInt(JOptionPane.showInputDialog("ingresar numero1: "));
        numeroMayor = numero1;
        
        numero2 = Integer.parseInt(JOptionPane.showInputDialog("ingresar numero2: "));
        if (numero2 > numeroMayor) {
            numeroMayor = numero2;
        }
        
        numero3 = Integer.parseInt(JOptionPane.showInputDialog("ingresar numero3: "));
        if (numero3 > numeroMayor) {
            numeroMayor = numero3;
        }
        
        numero4 = Integer.parseInt(JOptionPane.showInputDialog("ingresar numero4: "));
        if (numero4 > numeroMayor) {
            numeroMayor = numero4;
        }
        
        System.out.println("numero mayor: "+ numeroMayor);
    }
}
