/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2_semana2;
import javax.swing.JOptionPane;

/**
 *
 * @author josea
 */
public class Ejercicio2_semana2 {

    public static void main(String[] args) {
        int numero;
        numero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese numero de la semana"));
        
        if ((numero >= 2) && (numero <= 6)) {
            System.out.println("dia laboral");
        } else {
            System.out.println("dia libre");
        }
    }
}
